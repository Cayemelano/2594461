import java.util.Scanner;

public class Ej_6 {
    public static void main(String[] args) {
        int num1;
        int num2;
        double resultado;

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce el primer valor.");
        num1 = sc.nextInt();
        System.out.println("Introduce el segundo valor.");
        num2 = sc.nextInt();
        resultado = num1 + num2;
        System.out.println("La suma de "+num1+" y "+num2+" es de: "+resultado);
        resultado = num1 * num2;
        System.out.println("La multiplicacion de "+num1+" y "+num2+"6 es de: "+resultado);
        resultado = num1 / num2;
        System.out.println("El cociente de "+num1+" y "+num2+" es de: "+resultado);
        resultado = num2 % num1 ;
        System.out.println("El resto de "+num1+" y "+num2+" es de: "+resultado);
      
    }
}