
import java.util.Scanner;

public class Ej_1 {
    
    public static void main(String[] args) {
        int a;
        int b;

        Scanner sn = new Scanner(System.in);
        System.out.println("Introduzca el primer valor:");
        a = sn.nextInt();
        System.out.println("Introduzca el segundo valor:");
        b = sn.nextInt();

        if (a > b) {
            System.out.println("El numero mayor es "+a);            
        }
        else {
            System.out.println("El numero mayor es "+b);
        }
    }
}
