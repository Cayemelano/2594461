import java.util.Scanner;
public class Ej_3 {
    public static void main(String[] args) {
        int centimos;
        int resto;
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce el numero en centimos ente 1000 y 5000");
        centimos = sc.nextInt();

        if (centimos >= 1000 && 5000 >= centimos) {
            resto = centimos % 100;
            centimos = centimos / 100;
            System.out.println("Tienes "+centimos+"€ y "+resto+" centimos");

        }
        else {
            System.out.println("El valor introducido no es valido.");
        }
    }
}
