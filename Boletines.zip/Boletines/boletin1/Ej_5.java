import java.util.Scanner;

public class Ej_5 {
    public static void main(String[] args) {
        int area;
        int base;
        int altura;

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce la altura del triangulo:");
        altura = sc.nextInt();
        System.out.println("Introduce la base del triangulo");
        base = sc.nextInt();

        area = base *altura /2;
        System.out.println("El area es de "+area);
    }
}
