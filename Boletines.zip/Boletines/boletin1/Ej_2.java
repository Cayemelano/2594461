import java.util.Scanner;
public class Ej_2 {
    public static void main(String[] args) {
        int numero;
        Scanner sn = new Scanner(System.in);
        System.out.println("Introduce un numero:");
        numero = sn.nextInt();

        if (numero % 2 == 0) {
            System.out.println("El número " + numero + " es par.");
            }

        else {
            System.out.println("El número " + numero + " es impar.");
        }
    }
}
