import java.util.Scanner;
public class Ej_4 {
    public static void main(String[] args) {
        int salario;
        int sobreSueldo;
        int sueldoFinal;

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce tu salario(Debe de ser entre 800 y 3000)");
        salario = sc.nextInt();
        System.out.println("Introduce el porcentaje de sobre sueldo (Debe de estar entre 10% y 20%)");
        sobreSueldo = sc.nextInt();

        if (salario >= 800 && salario <= 3000 && sobreSueldo <= 20 && sobreSueldo >= 10) {
            System.out.println("El sueldo base es de "+ salario);
            System.out.println("El sobresueldo es de un "+sobreSueldo + "%");
            sueldoFinal = (salario*sobreSueldo) /100;
            salario = sueldoFinal + salario;
            System.out.println("El sueldo final es de "+ salario);
        }
        else{
            System.out.println("El valor introducido no es valido.");
        }
    }
}
