import java.util.Scanner;
public class Ej_4 {
    public static void main(String[] args) {
        int a;
        int b;
        int c;
        Scanner sn = new Scanner(System.in);
        System.out.println("Introduce el valor a:");
        a = sn.nextInt();
        System.out.println("Introduce el valor b:");
        b = sn.nextInt();
        System.out.println("Introduce el valor c:");
        c = sn.nextInt();

        if (a > b && a > c) {
            
            System.out.println("El numero "+a+" es el mayor");
        }
        if (b > a && b > c) {
            
            System.out.println("El numero "+b+" es el mayor");
        }
        else{          
            
            System.out.println("El numero "+c+" es el mayor");
          
        }
    }
}
