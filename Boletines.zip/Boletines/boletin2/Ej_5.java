import java.util.Scanner;
public class Ej_5 {
    public static void main(String[] args) {
        double radio;
        int area;
        int longitud;
        double volumen;

        Scanner sn = new Scanner(System.in);
        System.out.println("Introduce valor para el radio:");
        radio = sn.nextInt();

        area = (int) (3.1415 * (radio * radio));
        longitud = (int) (2 * 3.1415 * radio);
        volumen =  (4.0 / 3.0) * Math.PI * Math.pow(radio, 3);

        System.out.println("El area es "+area);
        System.out.println("La longitud es "+longitud);
        System.out.println("El volumen es "+volumen);
    }
}
