import java.util.Scanner;
public class Ej_7 {
    public static void main(String[] args) {
        double monedas;
        double monedaExtrangera;
        int convertidor;

        Scanner sn = new Scanner(System.in);

        System.out.println("Escriba el numero de dinero que desea convertir:");
        monedas = sn.nextDouble();
        System.out.println("Desea convertirlo a libras(1) o a euros(0)");
        convertidor = sn.nextInt();
        if (convertidor == 1) {
            System.out.println("---Convirtiendo de euros a libras---");
            monedaExtrangera = monedas * 0.82;
            System.out.println("En libras serian "+monedaExtrangera);
        }
        if (convertidor == 0) {
            System.out.println("---Convirtiendo de libras a euros---");
            monedaExtrangera = monedas * 1.20;
            System.out.println("En euros serian "+monedaExtrangera);
        }
    }
}
