import java.util.Scanner;

public class Ej_8 {
    public static void main(String[] args) {
        int a;
        int b;
        int c;
        Scanner sn = new Scanner(System.in);
        System.out.println("Introduce el valor para el lado a:");
        a = sn.nextInt();
        System.out.println("Introduce el valor para el lado b:");
        b = sn.nextInt();
        System.out.println("Introduce el valor para el lado c:");
        c = sn.nextInt();

        if (a == b && b != a|| b == c && b != a|| a == c && b != a) {
            System.out.println("Este triangulo es isosceles.");
        }
        else {
                 if (a == b && b == c && a == c) {
                    System.out.println("Este triangulo es equilatero.");
                    }
            else {
                 
                 if (a != b && b != c && a != c) {
                 System.out.println("Este triangulo es escaleno.");
        }
            }
        }
       
    }
}
