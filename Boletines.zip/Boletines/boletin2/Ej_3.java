import java.util.Scanner;
public class Ej_3 {
    public static void main(String[] args) {
        int salario;
        int horas;
        String nombre;

        Scanner sn = new Scanner(System.in);
        System.out.println("Introduce el nombre:");
        nombre = sn.nextLine();
        System.out.println("Introduzca el numero de horas trabajadas esta semana:");
        horas = sn.nextInt();
        if (horas > 35) {
            horas = horas -35;
            System.out.println("Esta semana has trabajado 35 horas a 20€ y "+horas+" a 30€.");
            salario = 35 * 20;
            salario = salario + horas * 30;         
        }
        else{
            System.out.println("Has tarabajado "+horas+" horas a 20€.");
            salario = horas * 20;
        }
        System.out.println("Tu salario bruto es de "+salario+"€.");
        
        if (salario > 700) {
            
            salario = salario - 700;
            salario = (int) (salario * 0.45);
            salario = (int) (salario + 662.5);
            System.out.println("Tu salario semanal es de "+salario+"€.");
        }
        if (salario > 350 && salario <= 700) {
            salario = salario -350;
            salario = (int) (salario * 0.25);
            salario = salario +350;
            System.out.println("Tu salario semanal es de "+salario+"€.");
            
        } else {
            System.out.println("Tu salaraio es de "+salario+"€ semanales.");
        }
    }
}
