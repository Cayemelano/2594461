import java.util.Scanner;

public class Ej_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int dia, mes, año, edad;     

        System.out.println("Introduzca el dia de nacimiento:");
        dia = sc.nextInt();
        System.out.println("Introduzca el mes de nacimiento:");
        mes = sc.nextInt();
        System.out.println("Introduzca el añ0o de nacimiento:");
        año = sc.nextInt();

        int diaActual = 19;
        int mesActual = 02;
        int añoActual = 2025;
         
        edad = añoActual - año;
        if (dia >= 31 || año >2025 || mes > 12) {
          System.out.println("Fecha introducida no valida.");
        }
        else {
             if (mesActual == mes && añoActual == año && diaActual == dia) {
                System.out.println("Felecidades, hoy cumples "+edad+" años");
            }
            else {
                if (mesActual < mes || mesActual < mes && diaActual < dia) {
                    edad --;
                    System.out.println("tu edad actual es de "+edad+" años");
                }
                else{
                        System.out.println("tu edad actual es de "+edad+" años");
                    }
                }
            }
    }
} 