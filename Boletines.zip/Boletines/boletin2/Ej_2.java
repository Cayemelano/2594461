import java.util.Scanner;
public class Ej_2{
    public static void main(String[] args) {
        int nota;
        Scanner sn = new Scanner (System.in);
        System.out.println("¿Que nota has sacado?");
        nota = sn.nextInt();

        if (nota < 3) {
            System.out.println("Vaya, eso es muy deficiente.");
        }
        else {
            if (nota < 5 && nota >= 3) {
                System.out.println("Vaya, eso es insuficiente.");
            }
            else {
                if (nota >= 5 && nota < 7)  {
                    System.out.println("Felicidades, eso es un bien.");
                }
                else {
                    if (nota >= 7 && nota < 9) {
                        System.out.println("Felicidades, eso es un notable.");
                    }
                    else {
                        if (nota <= 10) {
                            System.out.println("Felicidades, eso es un sobresaliente. <3");
                        }
                        else {
                            System.out.println("Nota introducida no valida.");
                        }
                    }
                }
            }
        }
    }
}