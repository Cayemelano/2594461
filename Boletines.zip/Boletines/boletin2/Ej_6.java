
public class Ej_6 {
    
}
